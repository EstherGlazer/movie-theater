package com.jpmc.theater;

public class InvalidMovieException extends RuntimeException {

	public InvalidMovieException(String message) {
		super(message);
	}

}
