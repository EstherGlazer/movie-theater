package com.jpmc.theater;

public class InvalidShowingException extends RuntimeException {

	public InvalidShowingException(String message) {
		super(message);
	}

}
