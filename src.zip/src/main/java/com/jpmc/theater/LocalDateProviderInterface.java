package com.jpmc.theater;

import java.time.LocalDate;

public interface LocalDateProviderInterface {
	public LocalDate currentDate();
}
